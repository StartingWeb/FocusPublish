﻿module.exports = {
    content: [
        "./Pages/**/*.{cshtml,razor,html}",
        "./Views/**/*.{cshtml,razor,html}"
    ],
    theme: { extend: {} },
    plugins: [],
};
